<?php
// Mostrar errores por pantalla
error_reporting(E_ALL);
ini_set ( 'display_errors', 1);

// Configuración de la url del sitio
define( 'SITE_URL', 'http://localhost/new-demo-proyect/domestika/tu-proyecto');

// Configuración de la zona horaria
define( 'SITE_TIMEZONE', 'Europe/Madrid');
define( 'SITE_LANG', ['es', 'spa', 'es_ES'] );

// Configuración de la conexión a la base de datos
define( 'DB_HOST', 'localhost');
define( 'DB_USER', 'root');
define( 'DB_PASS', 'root');
define( 'DB_DATABASE', 'microcms');
define( 'DB_PORT', '3306');
