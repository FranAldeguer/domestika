    </div>

    <footer id="footer">
      <div id="inner-footer">
        Curso de Introducción a PHP en Domestika
      </div>
    </footer>
  </body>
</html>
