<h1>Subir imagenes php </h1>

<!--  <form action="img-to-server.php" method="post" name="subida-imagenes" enctype="multipart/form-data"> -->
<form action="img-redimension.php" method="post" name="subida-imagenes" enctype="multipart/form-data">

  <label for="image-input">Elige una imagen para subir</label>
  <input type="file" id="imagen-input" name="image-input"><br>

  <input type="submit" name="enviar-img" value="ENVIAR V">

</form>
